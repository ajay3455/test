import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './hooks/useAuth';
import Login from './components/Login';
import SecurityHub from './components/SecurityHub';
import AboutMe from './components/AboutMe';
import ChatGPTTools from './components/ChatGPTTools';
import AIMessages from './components/AIMessages';
import HelpSection from './components/HelpSection';
import Locations from './components/Locations';

function App() {
  const { isAuthenticated, login } = useAuth();

  return (
    <Router>
      <Routes>
        <Route 
          path="/" 
          element={
            !isAuthenticated ? (
              <Login onLogin={login} />
            ) : (
              <Navigate to="/dashboard" replace />
            )
          } 
        />
        <Route 
          path="/dashboard" 
          element={
            isAuthenticated ? (
              <SecurityHub />
            ) : (
              <Navigate to="/" replace />
            )
          } 
        />
        <Route 
          path="/about" 
          element={
            isAuthenticated ? (
              <AboutMe />
            ) : (
              <Navigate to="/" replace />
            )
          } 
        />
        <Route 
          path="/chatgpt-tools" 
          element={
            isAuthenticated ? (
              <ChatGPTTools />
            ) : (
              <Navigate to="/" replace />
            )
          } 
        />
        <Route 
          path="/ai-messages" 
          element={
            isAuthenticated ? (
              <AIMessages />
            ) : (
              <Navigate to="/" replace />
            )
          } 
        />
        <Route 
          path="/faqs" 
          element={
            isAuthenticated ? (
              <HelpSection />
            ) : (
              <Navigate to="/" replace />
            )
          } 
        />
        <Route 
          path="/locations" 
          element={
            isAuthenticated ? (
              <Locations />
            ) : (
              <Navigate to="/" replace />
            )
          } 
        />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Router>
  );
}

export default App;