import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Phone, Wrench, Shield, AlertTriangle, Building2 } from 'lucide-react';
import Navigation from './Navigation';

interface Contact {
  service: string;
  name: string;
  phone: string;
  id?: string;
  priority?: 'high' | 'medium' | 'low';
}

function Directory() {
  const [searchTerm, setSearchTerm] = useState('');

  const contacts: Contact[] = [
    {
      service: "Insurance-Approved Flood/Restoration Contractor",
      name: "Interior Care - Stephen Gregersen",
      phone: "416-856-1650",
      priority: "high"
    },
    {
      service: "Insurance-Approved Flood/Restoration Contractor",
      name: "Respond Plus Disaster Restoration",
      phone: "905-567-7474",
      priority: "high"
    },
    {
      service: "Insurance-Approved Flood/Restoration Contractor",
      name: "Absolute Interior Restoration",
      phone: "416-804-1215",
      priority: "high"
    },
    {
      service: "Insurance Broker",
      name: "Atrens Counsel",
      phone: "905-567-2087"
    },
    {
      service: "Engineering",
      name: "Keller Engineering",
      phone: "519-940-0571"
    },
    {
      service: "General Contractor",
      name: "Nailed It Toronto",
      phone: "647-244-0672"
    },
    {
      service: "HVAC",
      name: "Contrast Heating",
      phone: "416-223-8552",
      priority: "medium"
    },
    {
      service: "Electrical",
      name: "Milestone Energy",
      phone: "416-569-7045",
      priority: "medium"
    },
    {
      service: "Plumbing",
      name: "Core Plumbing",
      phone: "416-871-7739",
      priority: "medium"
    },
    {
      service: "Generator",
      name: "Northern Generator",
      phone: "905-264-9744"
    },
    {
      service: "Generator Fuel",
      name: "N/A (Natural Gas Connection)",
      phone: ""
    },
    {
      service: "Elevators",
      name: "Otis Canada Inc.",
      phone: "1-800-233-6847",
      id: "FTM 557497",
      priority: "high"
    },
    {
      service: "Insurance",
      name: "Atrens Counsel",
      phone: "905-567-2087"
    },
    {
      service: "Security Systems & In-Suite Alarms",
      name: "The Automated Group - Tony Guarini",
      phone: "416-736-7722 x313",
      priority: "high"
    },
    {
      service: "Sprinkler Life Safety System",
      name: "Lifeline Fire Protection",
      phone: "416-850-9477",
      priority: "high"
    },
    {
      service: "Fire Panel",
      name: "Lifeline Fire Protection",
      phone: "416-850-9477",
      priority: "high"
    }
  ];

  const filteredContacts = contacts.filter(contact =>
    contact.service.toLowerCase().includes(searchTerm.toLowerCase()) ||
    contact.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    contact.phone.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", stiffness: 200, damping: 20 }}
            className="w-20 h-20 mx-auto mb-6 rounded-full bg-blue-100 flex items-center justify-center"
          >
            <Phone className="w-10 h-10 text-blue-600" />
          </motion.div>
          <h1 className="text-4xl font-bold text-blue-900 mb-4">Building Directory</h1>
          <p className="text-lg text-gray-600">
            Important contacts and emergency services
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="relative">
            <input
              type="text"
              placeholder="Search contacts..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full px-4 py-4 pl-12 rounded-xl border-0 
                bg-white/80 backdrop-blur-lg text-gray-900 
                shadow-lg focus:ring-2 focus:ring-blue-500"
            />
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          </div>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="grid grid-cols-1 md:grid-cols-2 gap-6"
        >
          {filteredContacts.map((contact, index) => (
            <motion.div
              key={index}
              variants={itemVariants}
              whileHover={{ scale: 1.02 }}
              className="bg-white/80 backdrop-blur-lg rounded-xl shadow-lg overflow-hidden
                transform transition-all duration-300 hover:shadow-xl"
            >
              <div className="p-6">
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="p-2 bg-blue-100 rounded-lg">
                      {contact.priority === 'high' ? (
                        <AlertTriangle className="w-6 h-6 text-red-500" />
                      ) : contact.service.includes('Security') ? (
                        <Shield className="w-6 h-6 text-blue-600" />
                      ) : (
                        <Wrench className="w-6 h-6 text-blue-600" />
                      )}
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900">{contact.service}</h3>
                      <p className="text-gray-600">{contact.name}</p>
                    </div>
                  </div>
                  {contact.priority === 'high' && (
                    <span className="px-3 py-1 bg-red-100 text-red-600 rounded-full text-sm font-medium">
                      Emergency
                    </span>
                  )}
                </div>

                <div className="mt-4 flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Phone className="w-5 h-5 text-gray-400" />
                    <a
                      href={`tel:${contact.phone}`}
                      className="text-blue-600 hover:text-blue-800 font-medium"
                    >
                      {contact.phone}
                    </a>
                  </div>
                  {contact.id && (
                    <span className="text-sm text-gray-500">
                      ID: {contact.id}
                    </span>
                  )}
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>

        {filteredContacts.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-12"
          >
            <Phone className="w-16 h-16 mx-auto text-gray-400 mb-4" />
            <h3 className="text-xl font-semibold text-gray-900 mb-2">No contacts found</h3>
            <p className="text-gray-600">
              Try adjusting your search terms
            </p>
          </motion.div>
        )}
      </div>
    </div>
  );
}

export default Directory;