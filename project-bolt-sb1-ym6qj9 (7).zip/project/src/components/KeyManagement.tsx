import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Filter, Copy, Key, AlertCircle } from 'lucide-react';
import Navigation from './Navigation';

interface KeyData {
  id: number;
  category: string;
  subcategory: string;
  keybox: string;
  description: string[];
}

const keys: KeyData[] = [
  {
    id: 1,
    category: "Cleaning Staff",
    subcategory: "Cleaner #1",
    keybox: "Cleaning Staff Keys",
    description: [
      "1 Common Area Key - AA",
      "1 FOB (8573)",
      "1 Garbage Cans Changeroom - W044",
      "1 Gym Tissue Dispenser Black Key",
      "1 Toilet Paper Dispenser Key - E114",
      "1 Salt Container Pad Lock - A389",
      "6th Floor Men's Changeroom Tissue dispenser - CAT74"
    ]
  },
  // ... previous key data remains the same ...
];

function KeyManagement() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [expandedKey, setExpandedKey] = useState<number | null>(null);

  const categories = Array.from(new Set(keys.map(key => key.category)));

  const filteredKeys = keys.filter(key =>
    (selectedCategory ? key.category === selectedCategory : true) &&
    (searchTerm ? (
      key.subcategory.toLowerCase().includes(searchTerm.toLowerCase()) ||
      key.description.some(desc => desc.toLowerCase().includes(searchTerm.toLowerCase())) ||
      key.keybox.toLowerCase().includes(searchTerm.toLowerCase())
    ) : true)
  );

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", stiffness: 200, damping: 20 }}
            className="w-20 h-20 mx-auto mb-6 rounded-full bg-blue-100 flex items-center justify-center"
          >
            <Key className="w-10 h-10 text-blue-600" />
          </motion.div>
          <h1 className="text-4xl font-bold text-blue-900 mb-4">Key Management</h1>
          <p className="text-lg text-gray-600">
            Track and manage building keys and access cards
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8 space-y-4"
        >
          {/* Search Bar */}
          <div className="relative">
            <input
              type="text"
              placeholder="Search keys by name, description, or location..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full px-4 py-4 pl-12 rounded-xl border-0 
                bg-white/80 backdrop-blur-lg text-gray-900 
                shadow-lg focus:ring-2 focus:ring-blue-500"
            />
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          </div>

          {/* Category Filter */}
          <div className="flex flex-wrap gap-2">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setSelectedCategory(null)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all
                ${!selectedCategory 
                  ? 'bg-blue-600 text-white' 
                  : 'bg-white/80 text-gray-600 hover:bg-blue-50'}`}
            >
              All Keys
            </motion.button>
            {categories.map(category => (
              <motion.button
                key={category}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setSelectedCategory(category)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all
                  ${selectedCategory === category 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-white/80 text-gray-600 hover:bg-blue-50'}`}
              >
                {category}
              </motion.button>
            ))}
          </div>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="grid grid-cols-1 md:grid-cols-2 gap-6"
        >
          {filteredKeys.map((key) => (
            <motion.div
              key={key.id}
              variants={itemVariants}
              whileHover={{ scale: 1.02 }}
              className="bg-white/80 backdrop-blur-lg rounded-xl shadow-lg overflow-hidden
                transform transition-all duration-300 hover:shadow-xl"
            >
              <motion.button
                onClick={() => setExpandedKey(expandedKey === key.id ? null : key.id)}
                className="w-full text-left"
              >
                <div className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="p-2 bg-blue-100 rounded-lg">
                        <Key className="w-6 h-6 text-blue-600" />
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold text-gray-900">{key.subcategory}</h3>
                        <p className="text-sm text-gray-600">{key.keybox}</p>
                      </div>
                    </div>
                    <span className="px-3 py-1 bg-blue-100 text-blue-600 rounded-full text-sm font-medium">
                      {key.category}
                    </span>
                  </div>

                  <AnimatePresence>
                    {expandedKey === key.id && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.3 }}
                        className="mt-4 pt-4 border-t border-gray-200"
                      >
                        <h4 className="font-medium text-gray-900 mb-2">Key Details:</h4>
                        <ul className="space-y-2">
                          {key.description.map((desc, index) => (
                            <motion.li
                              key={index}
                              initial={{ opacity: 0, x: -20 }}
                              animate={{ opacity: 1, x: 0 }}
                              transition={{ delay: index * 0.1 }}
                              className="flex items-center space-x-2 text-gray-600"
                            >
                              <span className="w-1.5 h-1.5 bg-blue-500 rounded-full"></span>
                              <span>{desc}</span>
                            </motion.li>
                          ))}
                        </ul>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </motion.button>
            </motion.div>
          ))}
        </motion.div>

        {filteredKeys.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-12"
          >
            <Key className="w-16 h-16 mx-auto text-gray-400 mb-4" />
            <h3 className="text-xl font-semibold text-gray-900 mb-2">No keys found</h3>
            <p className="text-gray-600">
              Try adjusting your search terms or filters
            </p>
          </motion.div>
        )}
      </div>
    </div>
  );
}

export default KeyManagement;