import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Clock, Calendar } from 'lucide-react';

function DateTime() {
  const [date, setDate] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setDate(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    }).format(date);
  };

  const formatTime = (date: Date) => {
    return new Intl.DateTimeFormat('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true
    }).format(date);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ scale: 1.02 }}
      className="w-full md:w-auto flex flex-col md:flex-row items-center justify-between 
        bg-gradient-to-r from-blue-600/90 to-indigo-600/90 
        backdrop-blur-lg text-white py-4 px-6 rounded-xl shadow-lg"
    >
      <motion.div 
        className="flex items-center mb-2 md:mb-0"
        whileHover={{ x: 5 }}
      >
        <Calendar className="w-5 h-5 mr-2" />
        <motion.span 
          className="text-lg font-medium"
          initial={{ opacity: 0.8 }}
          whileHover={{ opacity: 1 }}
        >
          {formatDate(date)}
        </motion.span>
      </motion.div>
      <motion.div 
        className="flex items-center md:ml-6"
        whileHover={{ x: 5 }}
      >
        <Clock className="w-5 h-5 mr-2" />
        <motion.span 
          className="text-xl font-bold font-mono"
          initial={{ opacity: 0.8 }}
          whileHover={{ opacity: 1 }}
        >
          {formatTime(date)}
        </motion.span>
      </motion.div>
    </motion.div>
  );
}

export default DateTime;