import React from 'react';
import { motion } from 'framer-motion';
import { Briefcase, Globe } from 'lucide-react';
import Navigation from './Navigation';

function AboutMe() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50">
      <Navigation />
      
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="pb-12"
      >
        {/* Header Section */}
        <motion.header
          initial={{ y: -50 }}
          animate={{ y: 0 }}
          className="relative text-center py-16 bg-white/80 backdrop-blur-lg shadow-md"
        >
          <h1 className="text-4xl font-bold text-blue-900">About Me</h1>
          <p className="mt-2 text-xl text-gray-600">
            Security Supervisor | Property Management Enthusiast | Technology Enthusiast
          </p>
        </motion.header>

        {/* Profile Image */}
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          className="relative -mt-16 mb-8"
        >
          <img
            src="https://i.imgur.com/eLwL4ir.jpeg"
            alt="Ajaypreet Singh"
            className="w-32 h-32 mx-auto rounded-full border-4 border-white shadow-lg object-cover"
          />
        </motion.div>

        <motion.section
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="max-w-4xl mx-auto px-4 text-center"
        >
          <h2 className="text-3xl font-bold text-blue-900 mb-6">
            Hello, I'm Ajaypreet Singh
          </h2>
          <p className="text-lg text-gray-700 mb-8">
            I'm a Security Supervisor at Regal Security Inc., leading security operations
            and training with over four years of experience in the industry. My passion
            lies in ensuring safety and creating secure environments.
          </p>

          {/* Skills Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
            <motion.div
              whileHover={{ scale: 1.05 }}
              className="bg-white/80 backdrop-blur-lg p-6 rounded-xl shadow-lg"
            >
              <Briefcase className="w-12 h-12 mx-auto text-blue-600 mb-4" />
              <h3 className="text-xl font-bold text-gray-900 mb-4">Top Skills</h3>
              <ul className="space-y-2 text-gray-600">
                <li>Physical Security</li>
                <li>Security Management</li>
                <li>Emergency Response</li>
                <li>CCTV Monitoring</li>
              </ul>
            </motion.div>

            <motion.div
              whileHover={{ scale: 1.05 }}
              className="bg-white/80 backdrop-blur-lg p-6 rounded-xl shadow-lg"
            >
              <Briefcase className="w-12 h-12 mx-auto text-blue-600 mb-4" />
              <h3 className="text-xl font-bold text-gray-900 mb-4">Certifications</h3>
              <ul className="space-y-2 text-gray-600">
                <li>Condominium Management Limited License</li>
                <li>First Aid, AED, and CPR - Level C</li>
                <li>Emergency Management</li>
                <li>Use of Force</li>
              </ul>
            </motion.div>

            <motion.div
              whileHover={{ scale: 1.05 }}
              className="bg-white/80 backdrop-blur-lg p-6 rounded-xl shadow-lg"
            >
              <Briefcase className="w-12 h-12 mx-auto text-blue-600 mb-4" />
              <h3 className="text-xl font-bold text-gray-900 mb-4">Languages</h3>
              <ul className="space-y-2 text-gray-600">
                <li>Punjabi (Native)</li>
                <li>Hindi (Native)</li>
                <li>English (Professional)</li>
              </ul>
            </motion.div>
          </div>

          {/* Contact Section */}
          <motion.div
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="mt-16 bg-blue-900/90 backdrop-blur-lg text-white py-12 px-4 rounded-xl shadow-lg"
          >
            <h2 className="text-3xl font-bold mb-6">Get In Touch</h2>
            <p className="text-lg mb-8">
              Want to know more about my professional journey?
            </p>
            <motion.a
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              href="https://www.ajaypreet.ca"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center px-6 py-3 bg-white/90 backdrop-blur-lg text-blue-900 rounded-lg font-semibold hover:bg-blue-50 transition-colors"
            >
              <Globe className="w-5 h-5 mr-2" />
              Visit My Website
            </motion.a>
          </motion.div>
        </motion.section>
      </motion.div>
    </div>
  );
}

export default AboutMe;