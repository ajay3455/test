import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, ChevronDown, ChevronUp, HelpCircle, AlertCircle, MessageCircle } from 'lucide-react';
import Navigation from './Navigation';

interface FAQ {
  category: string;
  question: string;
  answer: string;
  priority?: 'high' | 'medium' | 'low';
}

const faqs: FAQ[] = [
  // Building Access & Security
  {
    category: "Building Access & Security",
    question: "How do I get additional FOBs?",
    answer: "Each unit is initially provided with two FOBs. Additional FOBs can be purchased from the management office for $40 each, with a limit of 3 FOBs per suite. For security reasons, any unauthorized copied FOBs will be immediately deactivated along with the original FOB used for copying.",
    priority: "high"
  },
  {
    category: "Building Access & Security",
    question: "What should I do if I'm locked out of my suite?",
    answer: "If you're locked out, security staff can provide access if you are a registered resident and show valid ID matching our database. You can also store spare keys at the concierge desk for emergencies.",
    priority: "high"
  },
  {
    category: "Building Access & Security",
    question: "How do I get a garage remote?",
    answer: "Only owners with assigned parking spots can obtain garage remotes. There's a maximum of 2 remotes permitted per unit at $120 each.",
    priority: "medium"
  },
  {
    category: "Building Access & Security",
    question: "What happens if my FOB is detected as a copy?",
    answer: "Any FOB detected as an unauthorized copy will be immediately deactivated. Additionally, the original FOB used to create the copy will also be disabled for security purposes.",
    priority: "high"
  },
  {
    category: "Building Access & Security",
    question: "Can I get mobile phone access to the building?",
    answer: "Yes, resident owners can sign up for mobile phone door access. Please visit the Property Management Office to register for this service.",
    priority: "medium"
  },

  // Amenities & Facilities
  {
    category: "Amenities & Facilities",
    question: "What are the fitness center hours?",
    answer: "The fitness and yoga room is available from 6 AM to 11 PM, 7 days a week. No reservation is required, and it's free of charge.",
    priority: "high"
  },
  {
    category: "Amenities & Facilities",
    question: "How do I book the party room?",
    answer: "The 6th floor party room can be booked for $60 (including HST) through the Resident Online Portal. It's available from 11:30 AM to 11 PM and can accommodate up to 30 people.",
    priority: "medium"
  },
  {
    category: "Amenities & Facilities",
    question: "What are the pool hours and rules?",
    answer: "The heated pool on the 6th floor exterior lounge terrace is open from 10 AM to 11 PM, 7 days a week. Maximum 5 people per party are allowed. Note: The pool is closed during winter.",
    priority: "high"
  },
  {
    category: "Amenities & Facilities",
    question: "How do I book the theatre/karaoke room?",
    answer: "The theatre/karaoke room requires a booking fee of $15 for a 3-hour session. Payment must be made online at the time of booking and is non-refundable. Maximum 10 people per party.",
    priority: "medium"
  },
  {
    category: "Amenities & Facilities",
    question: "Are there guest suites available?",
    answer: "Yes, there are two furnished guest suites (304 & 305) available for $150 per night with a maximum stay of 5 nights. Reservations can be made through the Resident Online Portal.",
    priority: "medium"
  },

  // Moving & Deliveries
  {
    category: "Moving & Deliveries",
    question: "How do I book an elevator for moving?",
    answer: "Book Elevator #3 through Concierge Plus for moving. A non-refundable fee of $50 applies. New tenants who haven't completed registration must visit the Property Management Office to book.",
    priority: "high"
  },
  {
    category: "Moving & Deliveries",
    question: "What is the parcel acceptance policy?",
    answer: "Parcels are placed in the self-serve locker room on P1 or delivered to your unit. Packages must be picked up within 24 hours. Oversized packages that don't fit in the Parcel Machine will be delivered to your suite door.",
    priority: "high"
  },
  {
    category: "Moving & Deliveries",
    question: "What happens to unclaimed packages?",
    answer: "Packages not picked up within 24 hours will be returned to the sender or discarded. Due to space restrictions in the Parcel Room, there are no exceptions to this rule.",
    priority: "medium"
  },
  {
    category: "Moving & Deliveries",
    question: "Do you accept perishable deliveries?",
    answer: "No, perishable products (meal delivery services, groceries, flowers, etc.) will not be accepted by security or the Parcel Room.",
    priority: "medium"
  },

  // Pet Policies
  {
    category: "Pet Policies",
    question: "What are the building's pet rules?",
    answer: "Maximum 2 pets per suite, not exceeding 30 pounds each. Dogs must be leashed in common areas. Pets are not allowed in amenity areas. Pet owners must clean up after their pets or face a $250 fine. Exotic animals, rodents, livestock, or fowl are not permitted.",
    priority: "high"
  },
  {
    category: "Pet Policies",
    question: "Are pets allowed on balconies?",
    answer: "Pets are not allowed to be left unattended on balconies.",
    priority: "medium"
  },
  {
    category: "Pet Policies",
    question: "What happens if I violate pet policies?",
    answer: "Management and the board have the right to issue a 14-day pet removal order to any owner who fails to comply with the pet rules.",
    priority: "high"
  },
  {
    category: "Pet Policies",
    question: "Is there a pet washing facility?",
    answer: "Yes, there is a Pet Spa located on P1 with access to water. It's free of charge and available on a first-come, first-served basis.",
    priority: "medium"
  },

  // Parking
  {
    category: "Parking",
    question: "What are the visitor parking rules?",
    answer: "There are 5 visitor parking spots on P3. Units are allowed 6 visitor parking permits per month, valid for 24 hours each. Permits must be obtained from the concierge desk and displayed on the dashboard.",
    priority: "high"
  },
  {
    category: "Parking",
    question: "How do I register my bicycle?",
    answer: "Bicycle racks are available for a one-time non-refundable fee of $35. Registration is required and a permit will be attached to your bicycle frame.",
    priority: "medium"
  },
  {
    category: "Parking",
    question: "What happens to unauthorized parked vehicles?",
    answer: "Vehicles parked illegally will be ticketed and towed. Regular patrols are conducted and parking rules are enforced immediately.",
    priority: "high"
  },

  // Maintenance & Utilities
  {
    category: "Maintenance & Utilities",
    question: "How do I set up hydro for my unit?",
    answer: "Residents must open a hydro account with Provident for in-suite electricity consumption. Visit www.pemi.com to set up your account. Water and gas are included in maintenance fees.",
    priority: "high"
  },
  {
    category: "Maintenance & Utilities",
    question: "What are the garbage disposal rules?",
    answer: "Use garbage chutes between 7:30 AM and 10:30 PM only. Use small bags and don't throw oversized items or cardboard boxes down the chute. Bulk items should be taken to the Bulky Items Storage Room on P2.",
    priority: "high"
  },
  {
    category: "Maintenance & Utilities",
    question: "How often should I maintain my HVAC unit?",
    answer: "The corporation provides semi-annual inspection of heat pump units. Filters should be checked and cleaned regularly, and replaced every 3-4 months. Additional filters can be purchased from the management office.",
    priority: "medium"
  },
  {
    category: "Maintenance & Utilities",
    question: "How do I prevent plumbing issues?",
    answer: "Don't pour cooking fats, oil, grease, or food residues down drains. Clean dryer lint traps after each use, including the secondary trap in the exhaust duct.",
    priority: "medium"
  },

  // Property Management
  {
    category: "Property Management",
    question: "What are the property management office hours?",
    answer: "The office is located on the 5th floor and is open Monday to Friday, 9 AM to 5 PM. Contact: 647-368-7395 (Property Manager) or gloucester.on@fsresidential.com",
    priority: "high"
  },
  {
    category: "Property Management",
    question: "Is short-term rental allowed?",
    answer: "No, short-term rentals are strictly forbidden. All residents must be fully registered with property management and provide a minimum 6-month lease agreement if the unit is being leased.",
    priority: "high"
  },
  {
    category: "Property Management",
    question: "What insurance do I need?",
    answer: "All owners and tenants must have homeowners' insurance including coverage against the building deductible. The building insurance doesn't cover in-suite contents.",
    priority: "high"
  },
  {
    category: "Property Management",
    question: "How do I make alterations to my suite?",
    answer: "Owners must complete and submit a Renovation Request Form to the management office before making any alterations.",
    priority: "medium"
  }
];

function HelpSection() {
  const [searchTerm, setSearchTerm] = useState('');
  const [expandedCategories, setExpandedCategories] = useState<string[]>([]);
  const [expandedQuestions, setExpandedQuestions] = useState<string[]>([]);
  const [recentSearches, setRecentSearches] = useState<string[]>([]);
  const [showSearchSuggestions, setShowSearchSuggestions] = useState(false);

  useEffect(() => {
    // Automatically expand categories with matching search terms
    if (searchTerm) {
      const matchingCategories = new Set(
        faqs.filter(faq => 
          faq.question.toLowerCase().includes(searchTerm.toLowerCase()) ||
          faq.answer.toLowerCase().includes(searchTerm.toLowerCase())
        ).map(faq => faq.category)
      );
      setExpandedCategories(Array.from(matchingCategories));
    }
  }, [searchTerm]);

  const handleSearch = (term: string) => {
    setSearchTerm(term);
    if (term && !recentSearches.includes(term)) {
      setRecentSearches(prev => [term, ...prev].slice(0, 5));
    }
    setShowSearchSuggestions(false);
  };

  const toggleCategory = (category: string) => {
    setExpandedCategories(prev =>
      prev.includes(category)
        ? prev.filter(c => c !== category)
        : [...prev, category]
    );
  };

  const toggleQuestion = (question: string) => {
    setExpandedQuestions(prev =>
      prev.includes(question)
        ? prev.filter(q => q !== question)
        : [...prev, question]
    );
  };

  const filteredFaqs = faqs.reduce((acc: { [key: string]: FAQ[] }, faq) => {
    if (
      faq.question.toLowerCase().includes(searchTerm.toLowerCase()) ||
      faq.answer.toLowerCase().includes(searchTerm.toLowerCase())
    ) {
      acc[faq.category] = [...(acc[faq.category] || []), faq];
    }
    return acc;
  }, {});

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.5
      }
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50">
      <Navigation />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", stiffness: 200, damping: 20 }}
            className="w-20 h-20 mx-auto mb-6 rounded-full bg-blue-100 flex items-center justify-center"
          >
            <HelpCircle className="w-10 h-10 text-blue-600" />
          </motion.div>
          <h1 className="text-4xl font-bold text-blue-900 mb-4">Help Center</h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Find answers to common questions about The Gloucester on Yonge. 
            Can't find what you're looking for? Contact the management office.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8 relative"
        >
          <div className="relative">
            <input
              type="text"
              placeholder="Search for answers..."
              value={searchTerm}
              onChange={(e) => handleSearch(e.target.value)}
              onFocus={() => setShowSearchSuggestions(true)}
              className="w-full px-4 py-4 pl-12 rounded-xl border-0 
                bg-white/80 backdrop-blur-lg text-gray-900 
                shadow-lg focus:ring-2 focus:ring-blue-500
                transition-all duration-300"
            />
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            
            <AnimatePresence>
              {showSearchSuggestions && recentSearches.length > 0 && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="absolute w-full mt-2 py-2 bg-white/90 backdrop-blur-lg rounded-lg shadow-lg z-10"
                >
                  <div className="px-4 py-2 text-sm text-gray-500">Recent searches</div>
                  {recentSearches.map((search, index) => (
                    <motion.button
                      key={index}
                      whileHover={{ x: 5 }}
                      onClick={() => handleSearch(search)}
                      className="w-full px-4 py-2 text-left text-gray-700 hover:bg-blue-50/50"
                    >
                      {search}
                    </motion.button>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="space-y-6"
        >
          {Object.entries(filteredFaqs).map(([category, questions]) => (
            <motion.div
              key={category}
              variants={itemVariants}
              className="bg-white/80 backdrop-blur-lg rounded-xl shadow-lg overflow-hidden
                transform transition-all duration-300 hover:shadow-xl"
            >
              <motion.button
                whileHover={{ scale: 1.01 }}
                onClick={() => toggleCategory(category)}
                className="w-full px-6 py-4 flex items-center justify-between 
                  bg-gradient-to-r from-blue-600/90 to-indigo-600/90 text-white"
              >
                <span className="text-lg font-semibold">{category}</span>
                <motion.div
                  animate={{ rotate: expandedCategories.includes(category) ? 180 : 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <ChevronDown className="w-5 h-5" />
                </motion.div>
              </motion.button>

              <AnimatePresence>
                {expandedCategories.includes(category) && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                    className="overflow-hidden"
                  >
                    {questions.map((faq) => (
                      <motion.div
                        key={faq.question}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="border-t border-gray-200"
                      >
                        <motion.button
                          whileHover={{ backgroundColor: "rgba(59, 130, 246, 0.05)" }}
                          onClick={() => toggleQuestion(faq.question)}
                          className="w-full px-6 py-4 flex items-center justify-between text-left"
                        >
                          <div className="flex items-center space-x-3">
                            {faq.priority === 'high' && (
                              <AlertCircle className="w-5 h-5 text-red-500" />
                            )}
                            <span className="font-medium text-gray-900">{faq.question}</span>
                          </div>
                          <motion.div
                            animate={{ rotate: expandedQuestions.includes(faq.question) ? 180 : 0 }}
                            transition={{ duration: 0.3 }}
                          >
                            <ChevronDown className="w-5 h-5 text-gray-500" />
                          </motion.div>
                        </motion.button>

                        <AnimatePresence>
                          {expandedQuestions.includes(faq.question) && (
                            <motion.div
                              initial={{ height: 0, opacity: 0 }}
                              animate={{ height: "auto", opacity: 1 }}
                              exit={{ height: 0, opacity: 0 }}
                              transition={{ duration: 0.3 }}
                              className="overflow-hidden"
                            >
                              <div className="px-6 py-4 bg-gray-50/50">
                                <div className="flex items-start space-x-3">
                                  <MessageCircle className="w-5 h-5 text-blue-500 mt-1 flex-shrink-0" />
                                  <p className="text-gray-600">{faq.answer}</p>
                                </div>
                              </div>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </motion.div>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}
        </motion.div>

        {Object.keys(filteredFaqs).length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-12"
          >
            <motion.div
              animate={{ 
                scale: [1, 1.1, 1],
                rotate: [0, 5, -5, 0]
              }}
              transition={{ 
                duration: 2,
                repeat: Infinity,
                repeatType: "reverse"
              }}
              className="w-16 h-16 mx-auto mb-4 text-gray-400"
            >
              <AlertCircle className="w-full h-full" />
            </motion.div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">No results found</h3>
            <p className="text-gray-600">
              Try adjusting your search terms or browse through the categories
            </p>
          </motion.div>
        )}
      </div>
    </div>
  );
}

export default HelpSection;