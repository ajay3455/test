import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Star } from 'lucide-react';
import Navigation from './Navigation';
import DateTime from './DateTime';

interface Tool {
  title: string;
  description: string;
  url: string;
  icon: string;
  highlight?: boolean;
}

interface Tools {
  [key: string]: Tool[];
}

const tools: Tools = {
  dailyTools: [
    {
      title: 'Concierge Plus',
      description: 'Resident portal for building services and communications',
      url: 'https://gloucesteronyonge.conciergeplus.com/',
      icon: 'https://i.imgur.com/bvNiu43.png'
    },
    {
      title: 'Service Calendar',
      description: 'Track and manage contractor service requests',
      url: 'https://teamup.com/c/z74t22/gloucester-on-yonge',
      icon: 'https://i.imgur.com/kN11Ey5.png',
      highlight: true
    },
    {
      title: 'Spike (Email)',
      description: 'Email platform for security communications',
      url: 'https://spikenow.com/web/',
      icon: 'https://i.imgur.com/6W1JgS9.png'
    },
    {
      title: 'Connecteam',
      description: 'Security reports and team management hub',
      url: 'https://app.connecteam.com/index.html#/index/dashboard/dashboard',
      icon: 'https://i.imgur.com/dSi85T9.jpeg'
    },
    {
      title: 'Snaile Parcel Machine',
      description: 'Package tracking and management system',
      url: 'https://lockers.snailecloud.com/',
      icon: 'https://i.imgur.com/Rvef3GN.png'
    }
  ],
  printingHub: [
    {
      title: 'Sticky Notes',
      description: 'Print quick notes at front desk',
      url: 'https://ajay3455.github.io/notes/',
      icon: 'https://i.imgur.com/cZXg3Pn.png'
    },
    {
      title: 'Suite Entry Notice (Front Desk)',
      description: 'Generate notices for unit access - Front desk printer',
      url: 'https://ajay3455.github.io/suite-entry-notice-maker/',
      icon: 'https://i.imgur.com/7O6EOHU.png'
    },
    {
      title: 'Suite Entry Notice (Office)',
      description: 'Generate notices for unit access - Office printer',
      url: 'https://ajay3455.github.io/suite-entry-notice-office-v3/',
      icon: 'https://i.imgur.com/YjfoKnr.png'
    },
    {
      title: 'Unauthorized Parking Notice',
      description: 'Generate parking violation notices',
      url: 'https://ajay3455.github.io/unauthorized-parking-notice/',
      icon: 'https://seeklogo.com/images/N/no-parking-logo-A200D6F6C0-seeklogo.com.png'
    },
    {
      title: 'Exterior Parking Pass',
      description: 'Generate temporary parking passes',
      url: 'https://ajay3455.github.io/Parking-Pass-Valid/',
      icon: 'https://inps.net/traffic/sites/default/files/stock-products/RB-53%28DECAL%29_Parking_Replacement_Decal_INPS-010-22.jpg'
    }
  ],
  vehicleRecords: [
    {
      title: 'New Vehicle Registrations',
      description: 'View records of newly registered resident vehicles',
      url: 'https://docs.google.com/spreadsheets/d/17LJ0r202blPKfyaRf4YAF-vG038w4cj9rSS8GnR7_jo/edit?usp=sharing',
      icon: 'https://i.imgur.com/YjfoKnr.png'
    },
    {
      title: 'Vehicle Information Updates',
      description: 'Access log of changes to resident parking information',
      url: 'https://docs.google.com/spreadsheets/d/1GvnAAdh-U1FH85c4pQuZgsiH2OCZAk5mT98Jw1fGLjc/edit?usp=sharing',
      icon: 'https://i.imgur.com/7O6EOHU.png'
    }
  ],
  regalSecurity: [
    {
      title: 'Regal Security Portal',
      description: 'Access your employee portal',
      url: 'https://regalsecurityemployeeportal.cdn.thefmcloud.com/',
      icon: 'https://i.imgur.com/xCxLde3.png'
    },
    {
      title: 'Security Schedule',
      description: 'View your work schedule',
      url: 'https://app.connecteam.com/#/SchedulerLink?t=6b5b49b5-08ea-4ae7-8c3c-189ced1662f1',
      icon: 'https://i.imgur.com/xCxLde3.png'
    },
    {
      title: 'Regal Security Uniform Store',
      description: 'Purchase official Regal Security uniforms',
      url: 'https://regalsecurity.myshopify.com/',
      icon: 'https://i.imgur.com/xCxLde3.png'
    }
  ],
  aiTools: [
    {
      title: 'Chat GPTs',
      description: 'Access AI assistance tools',
      url: '/chatgpt-tools',
      icon: 'https://img.icons8.com/?size=512&id=iGqse5s20iex&format=png'
    },
    {
      title: 'AI Messages',
      description: 'Generate resident communications',
      url: '/ai-messages',
      icon: 'https://img.icons8.com/?size=512&id=iGqse5s20iex&format=png'
    },
    {
      title: 'DeepSeek Chat',
      description: 'Alternative AI chat assistant',
      url: 'https://chat.deepseek.com/',
      icon: 'https://i.imgur.com/AXAfpby.png'
    }
  ],
  additionalTools: [
    {
      title: 'Public Service Calendar',
      description: 'Access the public version of the service calendar',
      url: 'https://teamup.com/ksf38g8ut42kbe5uzt',
      icon: 'https://i.imgur.com/kN11Ey5.png'
    }
  ]
};

function SecurityHub() {
  const [searchTerm, setSearchTerm] = useState('');
  const [hoveredTool, setHoveredTool] = useState<string | null>(null);
  const [favorites, setFavorites] = useState<string[]>(() => {
    const saved = localStorage.getItem('favorites');
    return saved ? JSON.parse(saved) : [];
  });

  React.useEffect(() => {
    localStorage.setItem('favorites', JSON.stringify(favorites));
  }, [favorites]);

  const toggleFavorite = (toolTitle: string) => {
    setFavorites(prev => 
      prev.includes(toolTitle)
        ? prev.filter(title => title !== toolTitle)
        : [...prev, toolTitle]
    );
  };

  const enhancedTools = {
    ...(favorites.length > 0 && {
      favorites: Object.values(tools).flat().filter(tool => favorites.includes(tool.title))
    }),
    ...tools
  };

  const filteredTools = Object.entries(enhancedTools).map(([category, items]) => ({
    category: category.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase()),
    items: Array.isArray(items) ? items.filter(tool => 
      tool.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      tool.description.toLowerCase().includes(searchTerm.toLowerCase())
    ) : []
  })).filter(group => group.items.length > 0);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50">
      <Navigation dailyTools={tools.dailyTools} />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="flex flex-col md:flex-row justify-between items-center gap-4 mb-8"
        >
          <DateTime />
          <div className="relative w-full md:w-96">
            <motion.div
              whileHover={{ scale: 1.02 }}
              className="relative"
            >
              <input
                type="text"
                placeholder="Search tools by name or description..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full px-4 py-3 pl-10 rounded-xl border-0 
                  bg-white/80 backdrop-blur-lg text-gray-900 
                  shadow-lg focus:ring-2 focus:ring-blue-500"
              />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            </motion.div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="space-y-12"
        >
          {filteredTools.map(({ category, items }, categoryIndex) => (
            <motion.div
              key={category}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: categoryIndex * 0.1 }}
              className="space-y-6"
            >
              <motion.div 
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: categoryIndex * 0.1 }}
                className="flex items-center gap-3"
              >
                {category === 'Favorites' && <Star className="w-6 h-6 text-yellow-500" />}
                <h2 className="text-2xl font-bold text-blue-900">{category}</h2>
              </motion.div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <AnimatePresence>
                  {items.map((tool) => (
                    <motion.div
                      key={tool.title}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -20 }}
                      whileHover={{ scale: 1.03 }}
                      onHoverStart={() => setHoveredTool(tool.title)}
                      onHoverEnd={() => setHoveredTool(null)}
                    >
                      {tool.url.startsWith('/') ? (
                        <Link
                          to={tool.url}
                          className={`block p-6 rounded-xl transform transition-all
                            ${hoveredTool === tool.title ? 'translate-y-[-4px]' : ''}
                            bg-white/80 hover:bg-blue-50/90
                            backdrop-blur-lg shadow-lg hover:shadow-xl
                            ${tool.highlight ? 'ring-2 ring-orange-500' : ''}`}
                        >
                          <ToolContent 
                            tool={tool} 
                            isFavorite={favorites.includes(tool.title)}
                            onFavoriteToggle={() => toggleFavorite(tool.title)}
                          />
                        </Link>
                      ) : (
                        <a
                          href={tool.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className={`block p-6 rounded-xl transform transition-all
                            ${hoveredTool === tool.title ? 'translate-y-[-4px]' : ''}
                            bg-white/80 hover:bg-blue-50/90
                            backdrop-blur-lg shadow-lg hover:shadow-xl
                            ${tool.highlight ? 'ring-2 ring-orange-500' : ''}`}
                        >
                          <ToolContent 
                            tool={tool} 
                            isFavorite={favorites.includes(tool.title)}
                            onFavoriteToggle={() => toggleFavorite(tool.title)}
                          />
                        </a>
                      )}
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </div>
  );
}

interface ToolContentProps {
  tool: Tool;
  isFavorite: boolean;
  onFavoriteToggle: () => void;
}

function ToolContent({ tool, isFavorite, onFavoriteToggle }: ToolContentProps) {
  return (
    <div className="flex items-center space-x-4">
      <motion.div
        whileHover={{ rotate: [0, -10, 10, -10, 0] }}
        transition={{ duration: 0.5 }}
        className="flex-shrink-0 w-14 h-14 flex items-center justify-center 
          rounded-lg bg-gray-50/50 backdrop-blur-sm shadow-inner"
      >
        {typeof tool.icon === 'string' && tool.icon.startsWith('http') ? (
          <img src={tool.icon} alt="" className="w-10 h-10 object-contain" />
        ) : (
          <span className="text-3xl">{tool.icon}</span>
        )}
      </motion.div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between">
          <motion.h3
            whileHover={{ x: 5 }}
            className="text-lg font-semibold truncate text-gray-900"
          >
            {tool.title}
          </motion.h3>
          <motion.button
            whileHover={{ scale: 1.2 }}
            whileTap={{ scale: 0.9 }}
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              onFavoriteToggle();
            }}
            className="ml-2 text-gray-400 hover:text-yellow-500 transition-colors"
          >
            <Star className={`w-5 h-5 ${isFavorite ? 'fill-yellow-500 text-yellow-500' : ''}`} />
          </motion.button>
        </div>
        <motion.p
          initial={{ opacity: 0.8 }}
          whileHover={{ opacity: 1 }}
          className="text-sm text-gray-600"
        >
          {tool.description}
        </motion.p>
      </div>
    </div>
  );
}

export default SecurityHub;