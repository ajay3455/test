import React from 'react';
import { motion } from 'framer-motion';
import { ExternalLink, Copy, Calendar, MessageSquare } from 'lucide-react';

function ExtraTools() {
  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="min-h-screen py-8 px-4"
    >
      <div className="max-w-4xl mx-auto bg-white rounded-2xl shadow-xl overflow-hidden">
        <div className="p-8">
          <motion.div
            initial={{ y: -20 }}
            animate={{ y: 0 }}
            className="text-center mb-12"
          >
            <h1 className="text-4xl font-bold text-blue-900 mb-4">
              Password Protected Links
            </h1>
            <p className="text-xl text-gray-600">
              Select your secure destination or service
            </p>
          </motion.div>

          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="grid grid-cols-1 md:grid-cols-2 gap-6"
          >
            {/* Chat GPTs */}
            <motion.a
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              href="https://www.ajaypreet.com/chat-gpts-real-page"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center p-6 bg-white rounded-xl shadow-md hover:shadow-lg transition-all"
            >
              <MessageSquare className="w-12 h-12 text-blue-600 mr-4" />
              <div>
                <h3 className="text-xl font-semibold text-gray-900">Chat GPTs</h3>
                <p className="text-gray-600">Access AI assistance tools</p>
              </div>
            </motion.a>

            {/* Security Schedule */}
            <motion.a
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              href="https://app.connecteam.com/#/SchedulerLink?t=6b5b49b5-08ea-4ae7-8c3c-189ced1662f1"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center p-6 bg-white rounded-xl shadow-md hover:shadow-lg transition-all"
            >
              <Calendar className="w-12 h-12 text-blue-600 mr-4" />
              <div>
                <h3 className="text-xl font-semibold text-gray-900">
                  Security Schedule
                </h3>
                <p className="text-gray-600">View your work schedule</p>
              </div>
            </motion.a>

            {/* Service Calendar Section */}
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.3 }}
              className="md:col-span-2 p-6 bg-white rounded-xl shadow-md"
            >
              <div className="flex items-start space-x-4">
                <Calendar className="w-12 h-12 text-blue-600 flex-shrink-0" />
                <div className="flex-grow">
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">
                    Service Calendar
                  </h3>
                  <div className="bg-gray-50 p-3 rounded-lg mb-4">
                    <code className="text-sm text-gray-700">
                      teamup.com/ksf38g8ut42kbe5uzt
                    </code>
                  </div>
                  <div className="flex space-x-4">
                    <motion.a
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      href="https://teamup.com/ksf38g8ut42kbe5uzt"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center justify-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                    >
                      <ExternalLink className="w-4 h-4 mr-2" />
                      View Calendar
                    </motion.a>
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={() =>
                        copyToClipboard('https://teamup.com/ksf38g8ut42kbe5uzt')
                      }
                      className="flex items-center justify-center px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
                    >
                      <Copy className="w-4 h-4 mr-2" />
                      Copy Link
                    </motion.button>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </motion.div>
  );
}

export default ExtraTools;