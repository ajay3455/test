import React from 'react';
import { motion } from 'framer-motion';
import Navigation from './Navigation';
import { Search } from 'lucide-react';

function ChatGPTTools() {
  const gptTools = [
    {
      href: "https://chatgpt.com/g/g-CENHblsGg-concierge-contacts",
      title: "Concierge Contacts",
      icon: "https://img.icons8.com/?size=512&id=4KY3tfAid4dZ&format=png"
    },
    {
      href: "https://chatgpt.com/g/g-61UXxse92-condo-notice-maker",
      title: "Condo Notice Maker",
      icon: "https://img.icons8.com/?size=512&id=4KY3tfAid4dZ&format=png"
    },
    {
      href: "https://chatgpt.com/g/g-8lxz4l8jZ-fire-panel-expert",
      title: "Fire Panel Expert",
      icon: "https://img.icons8.com/?size=512&id=4KY3tfAid4dZ&format=png"
    },
    {
      href: "https://chatgpt.com/g/g-7LdnlhxUl-gloucester-in-suite-helper",
      title: "Gloucester In-Suite Helper",
      icon: "https://img.icons8.com/?size=512&id=4KY3tfAid4dZ&format=png"
    },
    {
      href: "https://chatgpt.com/g/g-9wAIzrDmY-the-gloucester-on-yonge-guide",
      title: "The Gloucester on Yonge Guide",
      icon: "https://img.icons8.com/?size=512&id=4KY3tfAid4dZ&format=png"
    },
    {
      href: "https://chatgpt.com/g/g-zZ6MZkUEX-gloucester-supervisor",
      title: "Gloucester Supervisor",
      icon: "https://img.icons8.com/?size=512&id=4KY3tfAid4dZ&format=png"
    },
    {
      href: "https://chatgpt.com/g/g-DU5yT5A05-incident-reports",
      title: "Incident Reports",
      icon: "https://img.icons8.com/?size=512&id=4KY3tfAid4dZ&format=png"
    },
    {
      href: "https://chatgpt.com/g/g-nhiOrJ3AO-protege-keypad-assistant",
      title: "Protege Keypad Assistant",
      icon: "https://img.icons8.com/?size=512&id=4KY3tfAid4dZ&format=png"
    },
    {
      href: "https://chatgpt.com/g/g-80DuwoZL4-snaile-parcel-locker",
      title: "Snaile Parcel Locker",
      icon: "https://img.icons8.com/?size=512&id=4KY3tfAid4dZ&format=png"
    }
  ];

  const [searchTerm, setSearchTerm] = React.useState('');
  const filteredTools = gptTools.filter(tool => 
    tool.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-[25px] shadow-[0_10px_40px_rgba(0,0,0,0.12)] p-8"
        >
          <h1 className="text-3xl font-bold text-center text-[#1a237e] mb-8">
            ChatGPT Custom GPTs
          </h1>

          {/* Search Bar */}
          <div className="max-w-md mx-auto mb-8 relative">
            <input
              type="text"
              placeholder="Search GPTs..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full px-4 py-3 pl-12 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
            />
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          </div>

          {/* GPT Tools Grid */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {filteredTools.map((tool, index) => (
              <motion.a
                key={index}
                href={tool.href}
                target="_blank"
                rel="noopener noreferrer"
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.98 }}
                className="flex items-center p-4 bg-blue-50 rounded-lg hover:bg-blue-100 transition-all"
              >
                <img src={tool.icon} alt={tool.title} className="w-12 h-12 mr-4" />
                <h3 className="font-semibold text-gray-800">{tool.title}</h3>
              </motion.a>
            ))}
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
}

export default ChatGPTTools;