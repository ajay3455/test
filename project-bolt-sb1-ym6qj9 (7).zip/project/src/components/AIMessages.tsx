import React from 'react';
import { motion } from 'framer-motion';
import Navigation from './Navigation';

function AIMessages() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50">
      <Navigation />
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
        className="w-full h-[calc(100vh-64px)]"
      >
        <iframe 
          src="/ai-messages.html"
          className="w-full h-full border-none"
          title="AI Messages System"
        />
      </motion.div>
    </div>
  );
}

export default AIMessages;