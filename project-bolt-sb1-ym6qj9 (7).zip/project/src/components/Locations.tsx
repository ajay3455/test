import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Building2, ArrowUpDown, Building } from 'lucide-react';
import Navigation from './Navigation';

interface Elevator {
  id: string;
  name: string;
  route: string;
  access: string[];
  schedule?: string;
  controlRoom: string;
  additionalInfo?: string;
}

function Locations() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const elevators: Elevator[] = [
    {
      id: "e1-4",
      name: "Elevators 1-4",
      route: "Ground floor → Penthouse (PH)",
      access: ["Residents only", "Loading dock access"],
      controlRoom: "Upper PentHouse",
      additionalInfo: "Main residential elevators"
    },
    {
      id: "e5",
      name: "Elevator 5",
      route: "Ground floor → 22nd floor",
      access: ["Ground floor", "Parking levels (P1-P4)"],
      controlRoom: "Near 21st Floor, on the left side of Suite 2115, near Stairwell C",
      additionalInfo: "Residential and parking access"
    },
    {
      id: "e6",
      name: "Elevator 6 (Loading Dock)",
      route: "Loading dock → All floors",
      schedule: "6am - 9pm",
      access: ["Booking required"],
      controlRoom: "Near the Commercial P1 Lobby and P1 Residential Visitor Bike Lockers",
      additionalInfo: "Service elevator"
    },
    {
      id: "e7",
      name: "Elevator 7",
      route: "Ground floor → 2nd floor, Ground floor → P1,P2,P3",
      access: ["Public access (2nd floor): 6am - 6pm", "Parking access (P1-P3): 6am - 12am"],
      controlRoom: "P3 Commercial Lobby",
      additionalInfo: "Commercial elevator"
    },
    {
      id: "e8",
      name: "Elevator 8",
      route: "Ground floor → P4",
      access: ["Ground floor", "P1", "P2", "P3", "P4"],
      controlRoom: "In P3, near Residential Elevator 8 Vestibule",
      additionalInfo: "Parking elevator"
    }
  ];

  const filteredElevators = elevators.filter(elevator =>
    elevator.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    elevator.route.toLowerCase().includes(searchTerm.toLowerCase()) ||
    elevator.access.some(a => a.toLowerCase().includes(searchTerm.toLowerCase())) ||
    (elevator.additionalInfo && elevator.additionalInfo.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", stiffness: 200, damping: 20 }}
            className="w-20 h-20 mx-auto mb-6 rounded-full bg-blue-100 flex items-center justify-center"
          >
            <Building2 className="w-10 h-10 text-blue-600" />
          </motion.div>
          <h1 className="text-4xl font-bold text-blue-900 mb-4">Building Elevators</h1>
          <p className="text-lg text-gray-600">
            Find information about elevator access and schedules
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="relative">
            <input
              type="text"
              placeholder="Search elevators..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full px-4 py-4 pl-12 rounded-xl border-0 
                bg-white/80 backdrop-blur-lg text-gray-900 
                shadow-lg focus:ring-2 focus:ring-blue-500"
            />
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          </div>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="grid grid-cols-1 md:grid-cols-2 gap-6"
        >
          {filteredElevators.map((elevator) => (
            <motion.div
              key={elevator.id}
              variants={itemVariants}
              className="bg-white/80 backdrop-blur-lg rounded-xl shadow-lg overflow-hidden
                transform transition-all duration-300 hover:shadow-xl"
            >
              <div className="p-6">
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="p-2 bg-blue-100 rounded-lg">
                      <Building className="w-6 h-6 text-blue-600" />
                    </div>
                    <h3 className="text-xl font-semibold text-gray-900">{elevator.name}</h3>
                  </div>
                  <motion.div
                    whileHover={{ y: -2 }}
                    className="px-3 py-1 bg-blue-100 rounded-full"
                  >
                    <span className="text-sm font-medium text-blue-600">
                      {elevator.id.toUpperCase()}
                    </span>
                  </motion.div>
                </div>

                <div className="mt-4 space-y-3">
                  <div className="flex items-start space-x-3">
                    <ArrowUpDown className="w-5 h-5 text-gray-400 mt-1" />
                    <div>
                      <p className="font-medium text-gray-900">Route</p>
                      <p className="text-gray-600">{elevator.route}</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-3">
                    <Building2 className="w-5 h-5 text-gray-400 mt-1" />
                    <div>
                      <p className="font-medium text-gray-900">Control Room</p>
                      <p className="text-gray-600">{elevator.controlRoom}</p>
                    </div>
                  </div>

                  <div className="border-t border-gray-200 pt-3">
                    <h4 className="font-medium text-gray-900 mb-2">Access Details:</h4>
                    <ul className="space-y-1">
                      {elevator.access.map((access, index) => (
                        <li key={index} className="text-gray-600 flex items-center space-x-2">
                          <span className="w-1.5 h-1.5 bg-blue-500 rounded-full"></span>
                          <span>{access}</span>
                        </li>
                      ))}
                      {elevator.schedule && (
                        <li className="text-gray-600 flex items-center space-x-2">
                          <span className="w-1.5 h-1.5 bg-blue-500 rounded-full"></span>
                          <span>Operating hours: {elevator.schedule}</span>
                        </li>
                      )}
                    </ul>
                  </div>

                  {elevator.additionalInfo && (
                    <div className="text-sm text-gray-500 italic">
                      {elevator.additionalInfo}
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>

        {filteredElevators.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-12"
          >
            <Building2 className="w-16 h-16 mx-auto text-gray-400 mb-4" />
            <h3 className="text-xl font-semibold text-gray-900 mb-2">No elevators found</h3>
            <p className="text-gray-600">
              Try adjusting your search terms
            </p>
          </motion.div>
        )}
      </div>
    </div>
  );
}

export default Locations;