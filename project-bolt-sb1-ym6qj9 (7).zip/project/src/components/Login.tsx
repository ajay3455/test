import React, { useState } from 'react';
import { motion } from 'framer-motion';

interface LoginProps {
  onLogin: (username: string, password: string) => void;
}

function Login({ onLogin }: LoginProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showHelp, setShowHelp] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLogin(username, password);
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4 bg-gradient-to-br from-[#f5f7fa] to-[#c3cfe2]">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="max-w-md w-full space-y-8 bg-white p-10 rounded-[25px] shadow-[0_10px_40px_rgba(0,0,0,0.12)] backdrop-blur-[10px]"
      >
        {showHelp && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="absolute inset-0 bg-white p-10 rounded-[25px] z-10 flex flex-col items-center justify-center space-y-6"
          >
            <h3 className="text-2xl font-bold text-[#1a237e]">Need Help?</h3>
            <p className="text-center text-gray-600">
              For account assistance, please contact the security supervisor:
            </p>
            <div className="text-center">
              <p className="font-bold text-lg text-[#1a237e]">Ajaypreet Singh</p>
            </div>
            <button
              onClick={() => setShowHelp(false)}
              className="mt-4 px-4 py-2 bg-[#1a237e] text-white rounded-md hover:bg-[#3949ab] transition-colors"
            >
              Back to Login
            </button>
          </motion.div>
        )}

        <div className="text-center">
          <motion.div
            initial={{ scale: 0.5 }}
            animate={{ scale: 1 }}
            transition={{ duration: 0.5 }}
            className="flex justify-center"
          >
            <img
              src="https://i.imgur.com/LmweghF.png"
              alt="Gloucester on Yonge Logo"
              className="h-24 w-auto object-contain"
            />
          </motion.div>
          <motion.h2
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="mt-6 text-3xl font-extrabold bg-gradient-to-r from-[#1a237e] to-[#3949ab] bg-clip-text text-transparent"
          >
            Gloucester Security Hub
          </motion.h2>
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="mt-2 text-sm text-[#546e7a]"
          >
            Please enter credentials to access the security resources
          </motion.p>
        </div>

        <motion.form
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="mt-8 space-y-6"
          onSubmit={handleSubmit}
        >
          <div className="space-y-4">
            <div>
              <input
                id="username"
                name="username"
                type="text"
                required
                className="appearance-none rounded-lg relative block w-full px-4 py-3 border border-gray-300 placeholder-gray-500 text-gray-900 focus:outline-none focus:ring-2 focus:ring-[#1a237e] focus:border-[#1a237e] sm:text-sm transition-all duration-200"
                placeholder="Enter username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
              />
            </div>
            <div>
              <input
                id="password"
                name="password"
                type="password"
                required
                className="appearance-none rounded-lg relative block w-full px-4 py-3 border border-gray-300 placeholder-gray-500 text-gray-900 focus:outline-none focus:ring-2 focus:ring-[#1a237e] focus:border-[#1a237e] sm:text-sm transition-all duration-200"
                placeholder="Enter password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
          </div>

          <div className="flex items-center justify-between text-sm">
            <button
              type="button"
              onClick={() => setShowHelp(true)}
              className="text-[#1a237e] hover:text-[#3949ab] font-medium"
            >
              Forgot credentials?
            </button>
            <button
              type="button"
              onClick={() => setShowHelp(true)}
              className="text-[#1a237e] hover:text-[#3949ab] font-medium"
            >
              Need an account?
            </button>
          </div>

          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            type="submit"
            className="group relative w-full flex justify-center py-3 px-4 border border-transparent text-sm font-medium rounded-lg text-white bg-[#1a237e] hover:bg-[#3949ab] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#1a237e] transition-all duration-200 shadow-lg hover:shadow-xl"
          >
            Access Security Hub
          </motion.button>
        </motion.form>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
          className="mt-6 text-center text-sm text-gray-500"
        >
          By accessing this system, you agree to follow all security protocols and guidelines
        </motion.div>
      </motion.div>
    </div>
  );
}

export default Login;