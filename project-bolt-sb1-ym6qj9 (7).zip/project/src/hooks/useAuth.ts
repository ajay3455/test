import { useState, useEffect } from 'react';

interface AuthHook {
  isAuthenticated: boolean;
  login: (username: string, password: string) => void;
  logout: () => void;
}

export function useAuth(): AuthHook {
  const [isAuthenticated, setIsAuthenticated] = useState(() => {
    return sessionStorage.getItem('isAuthenticated') === 'true';
  });

  const login = (username: string, password: string) => {
    if ((username === 'mike123' && password === 'mike123') || 
        (username === 'mike1234' && password === 'mike1234')) {
      setIsAuthenticated(true);
      sessionStorage.setItem('isAuthenticated', 'true');
    } else {
      alert('Invalid credentials. Please try again.');
    }
  };

  const logout = () => {
    setIsAuthenticated(false);
    sessionStorage.removeItem('isAuthenticated');
    window.location.href = '/';
  };

  return { isAuthenticated, login, logout };
}