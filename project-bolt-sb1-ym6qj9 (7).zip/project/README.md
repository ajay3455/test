# Gloucester Security Hub

A comprehensive security management portal for Gloucester on Yonge.

## Setup

1. Clone the repository
2. Install dependencies: `npm install`
3. Start development server: `npm run dev`

## Features

- Secure login system
- Guard links and resources
- Printing hub
- Vehicle records management
- Additional security tools